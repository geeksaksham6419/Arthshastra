import matplotlib.pyplot as plt

# Generate sample data and plot a graph
x = [1, 2, 3, 4, 5]
y = [10, 20, 25, 30, 35]

plt.plot(x, y)
plt.xlabel('X-axis')
plt.ylabel('Y-axis')
plt.title('Sample Graph')
plt.savefig('static/graph.png')  # Save the graph as graph.png in the static folder
