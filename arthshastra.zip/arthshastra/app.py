from flask import Flask, redirect, render_template, url_for, request
import os

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'csv'}

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/')
def welcome():
    return render_template('main.html')

@app.route('/index.html')
def index():
    return render_template('index.html')

@app.route('/report.html', methods=['GET', 'POST'])
def report():
    if request.method == 'POST':
        if 'csvFile' not in request.files:
            return redirect(request.url)
        file = request.files['csvFile']
        if file.filename == '':
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = 'data.csv'  # Rename the file if needed
            file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
            # Code for processing CSV file here
            return redirect(url_for('show_graph'))
    return render_template('report.html')

@app.route('/loan.html')
def loan():
    return render_template('loan.html')

@app.route('/options.html')
def options():
    return render_template('options.html')

@app.route('/budget')
def budget():
    return redirect(url_for('index'))

@app.route('/redirect_to_loan')
def redirect_to_loan():
    return redirect(url_for('loan'))

@app.route('/redirect_to_report')
def redirect_to_report():
    return redirect(url_for('report'))

@app.route('/logout')
def logout():
    return redirect(url_for('welcome'))

@app.route('/graph')
def show_graph():
    return redirect(url_for('static', filename='perk.html'))

if __name__ == '__main__':
    app.run(debug=True)
